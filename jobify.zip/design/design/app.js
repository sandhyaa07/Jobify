// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Example animation trigger on scroll
window.addEventListener('scroll', function() {
    let sections = document.querySelectorAll('section');
    sections.forEach(section => {
        let position = section.getBoundingClientRect().top;
        let windowHeight = window.innerHeight;
        if (position < windowHeight - 50) {
            section.classList.add('active');
        }
    });
});
